package rsvp

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"github.com/google/uuid"
	"github.com/sudhakarlarus/rsvp-generator/config"
	"github.com/sudhakarlarus/rsvp-generator/db"
	"github.com/sudhakarlarus/rsvp-generator/model"
	"go.mongodb.org/mongo-driver/bson"
	"golang.org/x/sync/errgroup"
	"log"
	"math/rand"
	"os"
	"runtime"
	"strconv"
	"time"
)

// D is a global variable that holds the MongoDB client.
var D db.Db

// JsonStream represents a stream of data from a JSON file
type JsonStream struct {
	batchChan chan []model.RSVPData
	doneChan  chan int
}

// ReadFile reads data from a JSON file and sends batches of data to batchChan.
// It closes batchChan when finished and waits for doneChan to be closed before returning.
func (cfg *JsonStream) ReadFile() error {
	cfg.batchChan = make(chan []model.RSVPData)
	cfg.doneChan = make(chan int)
	go cfg.Process()
	fPtr, err := os.Open("./input/meetup.json")
	if err != nil {
		log.Println("error in opening the json file:", err)
		return err
	}
	defer func(fptr *os.File) {
		err := fptr.Close()
		if err != nil {
			log.Println("error in closing the file:", err)
		}
	}(fPtr)
	fReader := bufio.NewReader(fPtr)
	fDecoder := json.NewDecoder(fReader)
	fDecoder.Token()
	batch := make([]model.RSVPData, 0, config.BatchSize)
	for fDecoder.More() {
		rsvpData := &model.RSVPData{}
		err := fDecoder.Decode(rsvpData)
		if err != nil {
			log.Println("error cfg parsing the meetup rsvp data:", err)
			continue
		}
		if rsvpData.Venue.VenueName == "" {
			continue
		}
		id, err := uuid.NewUUID()
		rsvpData.Id = id.String()
		batch = append(batch, *rsvpData)
		if len(batch) == config.BatchSize {
			cfg.batchChan <- batch
			batch = make([]model.RSVPData, 0, config.BatchSize)
		}
	}
	if len(batch) > 0 {
		cfg.batchChan <- batch
	}
	close(cfg.batchChan)
	<-cfg.doneChan
	return nil
}

// Process function is a method of JsonStream type in Go language.
// It reads data in batch from the channel batchChan and inserts it into a MongoDB collection named event-details
// under the database rsvp. The method is designed to run concurrently using the error group g with a limit set
// to the number of available CPU cores.
// For each batch of data, the method converts the slice of model.RSVPData into a slice of Go interfaces,
// which are then inserted into the MongoDB collection using the InsertMany method.
// If there is an error during the insert, it will log the error message.
// Once all batches have been processed and inserted,
// the method closes the doneChan channel to indicate that it has finished processing.
func (cfg *JsonStream) Process() {
	g := errgroup.Group{}
	g.SetLimit(runtime.NumCPU())
	db := D.GetClient()
	collection := db.Database("rsvp").Collection("event-details")
	for batch := range cfg.batchChan {
		interfaces := make([]interface{}, len(batch))
		for i, v := range batch {
			interfaces[i] = v
		}
		g.Go(func() error {
			_, err := collection.InsertMany(context.Background(), interfaces)
			if err != nil {
				log.Println("error with the event record insert:", err)
			}
			return nil
		})
	}
	g.Wait()
	cfg.doneChan <- 1
}

// FetchRSVPFeeds fetches RSVP event records from a MongoDB database and returns an array of model.RSVPData objects.
// The function does the following steps:
// It calls D.GetClient() to get a MongoDB client.
// It sets the collection to be the event-details collection in the rsvp database.
// It calls the Distinct method on the collection to get a list of distinct "event.event_id" values in the collection.
// It loops through the list of event IDs, and
// for each ID it finds the corresponding event record by calling the FindOne method on the collection and
// passing the event.event_id as the filter.
// It decodes the returned document into a model.RSVPData object and appends it to the events slice.
// Finally, it returns the events slice and a nil error. If an error occurs while finding event records,
// it returns a nil slice and the error.
func FetchRSVPFeeds() ([]*model.RSVPData, error) {

	db := D.GetClient()
	collection := db.Database("rsvp").Collection("event-details")

	eventRecords, err := collection.Distinct(context.Background(), "event.event_id", bson.D{})
	if err != nil {
		log.Println("error in finding event records:", err)
		return nil, err
	}
	log.Println("totally fetched event records:", len(eventRecords))
	var events []*model.RSVPData
	for _, v := range eventRecords {
		var data model.RSVPData
		err := collection.FindOne(context.TODO(), bson.M{"event.event_id": v}).Decode(&data)
		if err != nil {
			log.Println("error in finding an event record with event_id:", v, "error:", err)
			continue
		}
		events = append(events, &data)
	}

	return events, nil
}

// CreateRsvpFeed function creates a group of goroutines to update fields in each of the
// model.RSVPData events in the given events slice.
// The group has a limit set to the number of CPUs available in the runtime.
// In the loop, it waits for 1 second, then calls addFields function on each of the events in the events slice.
func CreateRsvpFeed(events []*model.RSVPData) {
	g := errgroup.Group{}
	g.SetLimit(runtime.NumCPU())
	for {
		for _, v := range events {
			time.Sleep(1 * time.Second)
			addFields(v)
		}
	}
}

// addFields function updates the following fields of the model.RSVPData struct instance v:
// Response
// Guests
// Member.MemberID
// Member.MemberName
// RSVPID
// Mtime (the current Unix timestamp)
func addFields(v *model.RSVPData) {
	v.Response = getResponse()
	v.Guests = getGuest()
	v.Member.MemberID = getMemberID()
	v.Member.MemberName = getMemberName()
	v.RSVPID = getRSVPID()
	v.Mtime = time.Now().UnixNano()
	producer(v)
}

// getRSVPID generates a random integer between 0 and 100000000 and returns it as a string of 6 digits.
func getRSVPID() int64 {
	rand.New(rand.NewSource(time.Now().UnixNano()))
	rsvpId, _ := strconv.ParseInt(fmt.Sprintf("%06d", rand.Intn(100000000)), 10, 64)
	return rsvpId
}

// getMemberName generates a random string "user_" concatenated with a random integer generated
// using the current UTC nanosecond as the max value.
func getMemberName() string {
	min := 0
	max := time.Now().UTC().Nanosecond()
	rand.New(rand.NewSource(time.Now().UnixNano()))
	return "user_" + strconv.Itoa(rand.Intn(max-min)+min)
}

// getMemberID generates a random integer between 0 and 100000000 and returns it as an int.
func getMemberID() int {
	rand.New(rand.NewSource(time.Now().UnixNano()))
	memberID, _ := strconv.Atoi(fmt.Sprintf("%08d", rand.Intn(100000000)))
	return memberID
}

// getGuest generates a random integer between 0 and 10 and returns it.
func getGuest() int {
	min := 0
	max := 10
	rand.New(rand.NewSource(time.Now().UnixNano()))
	return rand.Intn(max-min) + min
}

// getResponse() generates a random response either "Yes" or "No" depending on a random number generated.
// All the functions use time.Now().UnixNano() and rand.Intn() to generate random numbers with different seeds.
func getResponse() string {
	rand.New(rand.NewSource(time.Now().UnixNano()))
	min := 0
	max := 10
	if ((rand.Intn(max-min) + min) % 2) == 0 {
		return "Yes"
	}
	return "No"
}
