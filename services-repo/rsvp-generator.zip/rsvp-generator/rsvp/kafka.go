package rsvp

import (
	"context"
	"encoding/json"
	"github.com/segmentio/kafka-go"
	"github.com/sudhakarlarus/rsvp-generator/config"
	"github.com/sudhakarlarus/rsvp-generator/model"
	"log"
	"time"
)

// producer sends the RSVP data in the form of a JSON message to a specified Kafka topic.
// The message is written to the default partition of the topic, and a connection is established
// with the Kafka broker using the specified network and broker details.
func producer(m *model.RSVPData) {
	conn, err := kafka.DialLeader(context.Background(), config.KafkaNetwork, config.KafkaBroker, config.KafkaTopic, config.KafkaPartition)
	if err != nil {
		log.Fatal("failed to dial leader:", err)
	}
	b, err := json.Marshal(&m)
	if err != nil {
		log.Println(err)
	}
	conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
	_, err = conn.WriteMessages(kafka.Message{Value: b})
	if err != nil {
		log.Fatal("failed to write messages:", err)
	}
	log.Println("kafka write to topic:", config.KafkaTopic, "with rsvpid:", m.RSVPID)
	if err := conn.Close(); err != nil {
		log.Fatal("failed to close writer:", err)
	}
}
