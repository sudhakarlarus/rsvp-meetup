package config

// DbUri MongoDB connection string that specifies the host and
// port to connect to a MongoDB database running locally or remote
var DbUri = "mongodb://db:27017"

// KafkaTopic is the name of the Kafka topic to be read.
const KafkaTopic = "myTopic"

// KafkaBroker is a string addresses of the Kafka brokers.
const KafkaBroker = "kafka:9092"

// KafkaNetwork represents the network type to use when connecting to a Kafka server.
const KafkaNetwork = "tcp"

// KafkaPartition represents the default partition to use when sending messages to a Kafka topic.
const KafkaPartition = 0

// BatchSize defines the number of items in a batch
const BatchSize = 100
