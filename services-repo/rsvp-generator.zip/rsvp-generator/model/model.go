package model

// The RSVPData struct contains information about a meetup event, including venue, guest, member, and group details.
// The fields are annotated with bson and json tags to specify their keys when marshaling to/from
// BSON and JSON data formats. Id field is omitted when marshaling to JSON with json:"-".
type RSVPData struct {
	Id    string `json:"-" bson:"_id"`
	Venue struct {
		VenueName string  `bson:"venue_name" json:"venue_name"`
		Lon       float64 `bson:"lon" json:"lon"`
		Lat       float64 `bson:"lat" json:"lat"`
		VenueID   int     `bson:"venue_id" json:"venue_id"`
	} `bson:"venue" json:"venue"`
	Visibility string `bson:"visibility" json:"visibility"`
	Response   string `bson:"response" json:"response"`
	Guests     int    `bson:"guests" json:"guests"`
	Member     struct {
		MemberID   int    `bson:"member_id" json:"member_id"`
		Photo      string `bson:"photo" json:"photo"`
		MemberName string `bson:"member_name" json:"member_name"`
	} `bson:"member" json:"member"`
	RSVPID int64 `bson:"rsvp_id" json:"rsvp_id"`
	Mtime  int64 `bson:"mtime" json:"mtime"`
	Event  struct {
		EventName string `bson:"event_name" json:"event_name"`
		EventID   string `bson:"event_id" json:"event_id"`
		Time      int64  `bson:"time" json:"time"`
		EventURL  string `bson:"event_url" json:"event_url"`
	} `bson:"event" json:"event"`
	Group struct {
		GroupTopics []struct {
			URLKey    string `bson:"urlkey" json:"urlkey"`
			TopicName string `bson:"topic_name" json:"topic_name"`
		} `bson:"group_topics" json:"group_topics"`
		GroupCity    string  `bson:"group_city" json:"group_city"`
		GroupCountry string  `bson:"group_country" json:"group_country"`
		GroupID      int     `bson:"group_id" json:"group_id"`
		GroupName    string  `bson:"group_name" json:"group_name"`
		GroupLon     float64 `bson:"group_lon" json:"group_lon"`
		GroupURLName string  `bson:"group_urlname" json:"group_urlname"`
		GroupLat     float64 `bson:"group_lat" json:"group_lat"`
	} `bson:"group" json:"group"`
}
