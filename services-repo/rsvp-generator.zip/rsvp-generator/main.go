package main

import (
	"github.com/sudhakarlarus/rsvp-generator/rsvp"
	"log"
)

func main() {
	log.Println("starting the rsvp-generator service")
	log.Println("new kafka name change")
	input := rsvp.JsonStream{}
	err := input.ReadFile()
	if err != nil {
		log.Println("error in reading the file:", err)
	}
	events, err := rsvp.FetchRSVPFeeds()
	if err != nil {
		log.Println("error in fetching the rsvp feeds from db:", err)
	}
	log.Println("generating rsvp meetup feeds:")
	rsvp.CreateRsvpFeed(events)
	if err != nil {
		log.Println("stopping the rsvp-generator service")
	}
}
