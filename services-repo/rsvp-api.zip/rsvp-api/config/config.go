package config

// DbUri MongoDB connection string that specifies the host and
// port to connect to a MongoDB database running locally or remote
var DbUri = "mongodb://db:27017"
