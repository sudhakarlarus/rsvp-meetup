package handler

//func TestGetLocation(t *testing.T) {
//	d := &db.Db{}
//	config.DbUri = "mongodb://localhost:217"
//	client := d.GetClient()
//
//	if client == nil {
//		t.Fatalf("expected client to be not nil, got nil")
//	}
//	log.Println(client)
//	// Create a mock request
//	req, err := http.NewRequest("GET", "/get_location", nil)
//	if err != nil {
//		t.Fatal(err)
//	}
//
//	// Create a response recorder to store the response
//	rr := httptest.NewRecorder()
//
//	// Call the function under test
//	GetLocation(rr, req)
//
//	// Check that the status code is what we expect
//	assert.Equal(t, http.StatusOK, rr.Code)
//
//	// Check that the response body is what we expect
//	expected := `[]`
//	assert.Equal(t, expected, rr.Body.String())
//}
//
//func TestGetLocationWithError(t *testing.T) {
//	// Create a mock request
//	req, err := http.NewRequest("GET", "/get_location", nil)
//	if err != nil {
//		t.Fatal(err)
//	}
//
//	// Create a response recorder to store the response
//	rr := httptest.NewRecorder()
//
//	// Call the function under test with an error
//	D.Client = nil
//	GetLocation(rr, req)
//
//	// Check that the status code is what we expect
//	assert.Equal(t, http.StatusServiceUnavailable, rr.Code)
//
//	// Check that the response body is what we expect
//	expected := `problem with server resource`
//	assert.Equal(t, expected, rr.Body.String())
//}

//func TestGetLocation(t *testing.T) {
//	type expectedResult struct {
//		statusCode int
//		header     http.Header
//		body       []model.LocationResponse
//	}
//
//	tests := []struct {
//		name           string
//		expectedResult expectedResult
//		mockDB         func() *mongo.Client
//	}{
//		{
//			name: "Test Case 1: Successful response",
//			expectedResult: expectedResult{
//				statusCode: 200,
//				header: http.Header{
//					"Content-Type": []string{"application/json"},
//				},
//				body: []model.LocationResponse{
//					{
//						VenueName: "venue 1",
//						EventName: "event 1",
//						Country:   "country 1",
//						City:      "city 1",
//					},
//					{
//						VenueName: "venue 2",
//						EventName: "event 2",
//						Country:   "country 2",
//						City:      "city 2",
//					},
//				},
//			},
//			mockDB: func() *mongo.Client {
//				findResult := &mongo.Cursor{}
//				findResult.Next = func(context.Context) bool {
//					return true
//				}
//				findResult.Decode = func(interface{}) error {
//					return nil
//				}
//				findResult.Close = func(context.Context) error {
//					return nil
//				}
//
//				client := &mongo.Client{}
//				client.Database = func(string) *mongo.Database {
//					db := &mongo.Database{}
//					db.Collection = func(string) *mongo.Collection {
//						c := &mongo.Collection{}
//						c.Find = func(context.Context, interface{}, ...*options.FindOptions) (*mongo.Cursor, error) {
//							return findResult, nil
//						}
//						return c
//					}
//					return db
//				}
//				return client
//			},
//		},
//		{
//			name: "Test Case 2: Error response",
//			expectedResult: expectedResult{
//

//package your_package
//
//import (
//"net/http"
//"net/http/httptest"
//"testing"
//
//"github.com/stretchr/testify/assert"
//)
//
//func TestGetLocation(t *testing.T) {
//	// mock the response from mongodb
//	// for this you can create a fake collection which implements the same interface as mongodb collection
//	// and returns the data you want to test with
//	fakeCollection := &FakeCollection{}
//
//	// create a new Db instance and set the Client to the fake collection
//	D = db.Db{
//		Client: &mongo.Client{
//			Database: func(name string) *mongo.Database {
//				return &mongo.Database{
//					Collection: func(name string) *mongo.Collection {
//						return fakeCollection
//					},
//				}
//			},
//		},
//	}
//
//	// Create a request to pass to the handler
//	req, err := http.NewRequest("GET", "/", nil)
//	if err != nil {
//		t.Fatal(err)
//	}
//
//	// Create a ResponseRecorder to record the response
//	rr := httptest.NewRecorder()
//	handler := http.HandlerFunc(GetLocation)
//
//	// Serve the request to the handler
//	handler.ServeHTTP(rr, req)
//
//	// Check the status code is what we expect
//	assert.Equal(t, http.StatusOK, rr.Code)
//
//	// check the response body is what we expect
//	expected := `[{"VenueName":"venue1","EventName":"event1","Country":"country1","City":"city1"},{"VenueName":"venue2","EventName":"event2","Country":"country2","City":"city2"}]`
//	assert.Equal(t, expected, rr.Body.String())
//}
//
//// fakeCollection is a fake implementation of mongodb collection
//type FakeCollection struct{}
//
//func (c *FakeCollection) Find(ctx context.Context, filter interface{}, opts ...*options.FindOptions) (*mongo.Cursor, error) {
//	// return a fake cursor which returns the data you want to test with
//	return &FakeCursor{}, nil
//}
//
//// fakeCursor is a fake implementation of mongodb cursor
//type FakeCursor struct{}
//
//func (c *FakeCursor) Close(ctx context.Context) error {
//	return nil
//}
//
//func (c *FakeCursor) Decode(val interface{}) error {
//	switch v := val.(type) {
//	case *model.LocationResponse:
//		*v = model.LocationResponse{
//			VenueName: "venue1",
//			EventName: "event1",
//			Country:   "country1",
//			City:      "city1",
//		}
//		return nil
//	default:
//		return fmt.Errorf("unexpected type %T", v)
//	}
//}
//
//func (c *FakeCursor) Next(ctx context.Context)
