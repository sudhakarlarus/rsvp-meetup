package handler

import (
	"context"
	"encoding/json"
	"github.com/sudhakarlarus/rsvp-api/db"
	"github.com/sudhakarlarus/rsvp-api/model"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"log"
	"net/http"
)

// D is a global variable that holds the MongoDB client.
var D db.Db

// GetLocation handles a GET request for the popular locations.
// It returns a JSON response containing the location data.
func GetLocation(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	d := D.GetClient()
	collection := d.Database("rsvp").Collection("processed-batch")
	filter := bson.D{{}}
	cur, err := collection.Find(r.Context(), filter, options.Find().SetSort(bson.D{{"response_count", -1}, {"guests", -1}, {"last_mtime", -1}}))
	if err != nil {
		log.Println("error while finding the popular location:", err)
		http.Error(w, "problem with server resource", 503)
		return
	}
	defer func(cur *mongo.Cursor, ctx context.Context) {
		err := cur.Close(ctx)
		if err != nil {
			log.Println("error in db cursor closing:", err)
		}
	}(cur, r.Context())
	var locationResponse []model.LocationResponse
	for cur.Next(r.Context()) {
		var record model.LocationResponse
		err := cur.Decode(&record)
		if err != nil {
			log.Println("error while parsing the db record:", err)
		}
		locationResponse = append(locationResponse, record)
	}
	err = json.NewEncoder(w).Encode(locationResponse)
	if err != nil {
		log.Println("error in json encoding:", err)
		return
	}
}
