package main

import (
	"github.com/gorilla/mux"
	"github.com/sudhakarlarus/rsvp-api/handler"
	"log"
	"net/http"
)

func main() {
	log.Println("starting the rsvp-api service")
	r := mux.NewRouter()
	r.HandleFunc("/location", handler.GetLocation).Methods("GET")
	err := http.ListenAndServe(":8080", r)
	if err != nil {
		log.Println("stopping the rsvp-api service")

	}
}
