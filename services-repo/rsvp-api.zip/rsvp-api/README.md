# rsvp-api

## Description
Provides REST API endpoint to get the top trending locations for meetup.

## High level design

![](doc/high-level.png)

## Installation
### Prerequisite
* Golang 1.19 and above
* Docker v20.10.14 and above.
* MongoDB latest

## Execution
Use this [Postman](doc/RSVP.postman_collection.json) file to try the **/location** API endpoint.
### Output screenshots
![img.png](doc/location_api.png)

## Contact
For any discussion or feedback, please free to reach me over
[LinkedIn](https://www.linkedin.com/in/sudhakar-padmanaban-b2047588/) , [Mail](sudhakarpadmanaban14@gmail.com).
