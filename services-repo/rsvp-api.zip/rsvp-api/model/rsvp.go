package model

// LocationResponse represents a response for a location-related query.
type LocationResponse struct {
	// VenueName is the name of the venue.
	VenueName string `bson:"venue_name" json:"venue_name"`
	// EventName is the name of the event.
	EventName string `bson:"event_name" json:"event_name"`
	// Country is the country where the event is taking place.
	Country string `json:"country" bson:"group_country"`
	// City is the city where the event is taking place.
	City string `json:"city" bson:"group_city"`
}
