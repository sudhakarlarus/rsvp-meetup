package db

import (
	"testing"
)

func TestConnect(t *testing.T) {
	d := &Db{}
	client, err := d.connect("mongodb://localhost:27017")
	if err != nil {
		t.Fatalf("error connecting to database: %v", err)
	}
	if client == nil {
		t.Fatalf("expected client to be not nil, got nil")
	}
	defer d.Cancel()
}

func TestGetClient(t *testing.T) {
	d := &Db{}
	client := d.GetClient()
	if client == nil {
		t.Fatalf("expected client to be not nil, got nil")
	}
	defer d.Cancel()
}
