package db

import (
	"context"
	"github.com/sudhakarlarus/rsvp-api/config"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"time"
)

// Db struct with Cancel and Client attributes.
type Db struct {
	Cancel context.CancelFunc
	Client *mongo.Client
}

// connect method creates a context with timeout, sets the "Cancel" field to the cancel function of the context, and
// connects to a MongoDB database using the provided "dbUri"
func (db *Db) connect(dbUri string) (*mongo.Client, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	db.Cancel = cancel
	return mongo.Connect(ctx, options.Client().ApplyURI(dbUri))
}

// GetClient creates a new MongoDB client and returns it if it does not exist.
// If the client has already been created, the function returns the existing client.GetClient creates a new MongoDB client and returns it if it does not exist. If the client has already been created, the function returns the existing client.
func (db *Db) GetClient() *mongo.Client {
	var err error
	if db.Client == nil {
		db.Client, err = db.connect(config.DbUri)
		if err != nil {
			panic(err)
		}
	}
	return db.Client
}
