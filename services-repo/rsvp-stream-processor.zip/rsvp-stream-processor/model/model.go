package model

// The RSVPData struct contains information about a meetup event, including venue, guest, member, and group details.
// The fields are annotated with bson and json tags to specify their keys when marshaling to/from
// BSON and JSON data formats. Id field is omitted when marshaling to JSON with json:"-".
type RSVPData struct {
	Id    string `json:"-" bson:"_id"`
	Venue struct {
		VenueName string  `bson:"venue_name" json:"venue_name"`
		Lon       float64 `bson:"lon" json:"lon"`
		Lat       float64 `bson:"lat" json:"lat"`
		VenueID   int     `bson:"venue_id" json:"venue_id"`
	} `bson:"venue" json:"venue"`
	Visibility string `bson:"visibility" json:"visibility"`
	Response   string `bson:"response" json:"response"`
	Guests     int    `bson:"guests" json:"guests"`
	Member     struct {
		MemberID   int    `bson:"member_id" json:"member_id"`
		Photo      string `bson:"photo" json:"photo"`
		MemberName string `bson:"member_name" json:"member_name"`
	} `bson:"member" json:"member"`
	RSVPID int64 `bson:"rsvp_id" json:"rsvp_id"`
	Mtime  int64 `bson:"mtime" json:"mtime"`
	Event  struct {
		EventName string `bson:"event_name" json:"event_name"`
		EventID   string `bson:"event_id" json:"event_id"`
		Time      int64  `bson:"time" json:"time"`
		EventURL  string `bson:"event_url" json:"event_url"`
	} `bson:"event" json:"event"`
	Group struct {
		GroupTopics []struct {
			URLKey    string `bson:"urlkey" json:"urlkey"`
			TopicName string `bson:"topic_name" json:"topic_name"`
		} `bson:"group_topics" json:"group_topics"`
		GroupCity    string  `bson:"group_city" json:"group_city"`
		GroupCountry string  `bson:"group_country" json:"group_country"`
		GroupID      int     `bson:"group_id" json:"group_id"`
		GroupName    string  `bson:"group_name" json:"group_name"`
		GroupLon     float64 `bson:"group_lon" json:"group_lon"`
		GroupURLName string  `bson:"group_urlname" json:"group_urlname"`
		GroupLat     float64 `bson:"group_lat" json:"group_lat"`
	} `bson:"group" json:"group"`
	BatchId int `bson:"batchId" json:"-"`
}

// FlatRsvpdata is a struct that holds information about an RSVP event.
// It has fields for venue name, longitude and latitude, venue ID, visibility, response, number of guests,
// member ID, photo, member name, RSVP ID, modification time, event name, event ID, event time,
// event URL, group topics, group city, group country, group ID, group name, group longitude, group URL name,
// group latitude, and batch ID. The fields have both bson and json tags to indicate the field names
// when serializing the struct to a BSON or JSON format, respectively.
type FlatRsvpdata struct {
	VenueName   string  `bson:"venue_name" json:"venue_name"`
	Lon         float64 `bson:"lon" json:"lon"`
	Lat         float64 `bson:"lat" json:"lat"`
	VenueID     int     `bson:"venue_id" json:"venue_id"`
	Visibility  string  `bson:"visibility" json:"visibility"`
	Response    string  `bson:"response" json:"response"`
	Guests      int     `bson:"guests" json:"guests"`
	MemberID    int     `bson:"member_id" json:"member_id"`
	Photo       string  `bson:"photo" json:"photo"`
	MemberName  string  `bson:"member_name" json:"member_name"`
	RSVPID      int64   `bson:"rsvp_id" json:"rsvp_id"`
	Mtime       int64   `bson:"mtime" json:"mtime"`
	EventName   string  `bson:"event_name" json:"event_name"`
	EventID     string  `bson:"event_id" json:"event_id"`
	Time        int64   `bson:"time" json:"time"`
	EventURL    string  `bson:"event_url" json:"event_url"`
	GroupTopics []struct {
		URLKey    string `bson:"urlkey" json:"urlkey"`
		TopicName string `bson:"topic_name" json:"topic_name"`
	} `bson:"group_topics" json:"group_topics"`
	GroupCity    string  `bson:"group_city" json:"group_city"`
	GroupCountry string  `bson:"group_country" json:"group_country"`
	GroupID      int     `bson:"group_id" json:"group_id"`
	GroupName    string  `bson:"group_name" json:"group_name"`
	GroupLon     float64 `bson:"group_lon" json:"group_lon"`
	GroupURLName string  `bson:"group_urlname" json:"group_urlname"`
	GroupLat     float64 `bson:"group_lat" json:"group_lat"`
	BatchId      int     `bson:"batch_id" json:"-"`
}

// ProcessedRsvpData represents a processed RSVP data structure, with fields mapping to RSVP data stored in a data store, such as BSON or JSON.
// VenueName: the name of the venue
// Lon: the longitude of the venue
// Lat: the latitude of the venue
// VenueID: the identifier of the venue
// Visibility: the visibility of the event
// ResponseCount: the number of responses to the event
// Guests: the number of guests attending the event
// LastRSVPID: the last RSVP identifier
// LastMtime: the last modification time
// EventName: the name of the event
// EventID: the identifier of the event
// Time: the time of the event
// EventURL: the URL of the event
// GroupTopics: a slice of structs containing information about the topics of the event's group
// GroupCity: the city of the event's group
// GroupCountry: the country of the event's group
// GroupID: the identifier of the event's group
// GroupName: the name of the event's group
// GroupLon: the longitude of the event's group
// GroupLat: the latitude of the event's group
// ProcessedBatchId: the identifier of the processed batch (omitted from JSON encoding)
type ProcessedRsvpData struct {
	VenueName     string  `bson:"venue_name" json:"venue_name"`
	Lon           float64 `bson:"lon" json:"lon"`
	Lat           float64 `bson:"lat" json:"lat"`
	VenueID       int     `bson:"venue_id" json:"venue_id"`
	Visibility    string  `bson:"visibility" json:"visibility"`
	ResponseCount int     `bson:"response_count" json:"response_count"`
	Guests        int     `bson:"guests" json:"guests"`
	LastRSVPID    int64   `bson:"last_rsvp_id" json:"last_rsvp_id"`
	LastMtime     int64   `bson:"last_mtime" json:"last_mtime"`
	EventName     string  `bson:"event_name" json:"event_name"`
	EventID       string  `bson:"event_id" json:"event_id"`
	Time          int64   `bson:"time" json:"time"`
	EventURL      string  `bson:"event_url" json:"event_url"`
	GroupTopics   []struct {
		URLKey    string `bson:"urlkey" json:"urlkey"`
		TopicName string `bson:"topic_name" json:"topic_name"`
	} `bson:"group_topics" json:"group_topics"`
	GroupCity        string  `bson:"group_city" json:"group_city"`
	GroupCountry     string  `bson:"group_country" json:"group_country"`
	GroupID          int     `bson:"group_id" json:"group_id"`
	GroupName        string  `bson:"group_name" json:"group_name"`
	GroupLon         float64 `bson:"group_lon" json:"group_lon"`
	GroupLat         float64 `bson:"group_lat" json:"group_lat"`
	ProcessedBatchId int     `bson:"processed_batch_id" json:"-"`
}
