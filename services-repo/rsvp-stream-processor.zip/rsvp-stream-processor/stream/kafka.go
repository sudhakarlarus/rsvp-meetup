package stream

import (
	"context"
	"github.com/segmentio/kafka-go"
	"github.com/sudhakarlarus/rsvp-stream-processor/config"
	"log"
	"sync"
)

// Kafka struct represents the configuration for a Kafka client.
type Kafka struct {
	Brokers     []string
	Topic       string
	StartOffset int64
	GroupID     string
}

// Consumer method is a method of the Kafka struct.
// It sets up a Kafka reader and reads messages from the specified Kafka broker and topic.
// The messages are processed in batches of size config.BatchSize and parsed by the parseRsvpData function in a separate goroutine.
// The method returns an error if there is a problem with the Kafka reader.
// The method uses a WaitGroup to wait for all goroutines to complete before returning.
func (kr *Kafka) Consumer() error {

	kafkaReader := kafka.NewReader(kafka.ReaderConfig{
		Brokers:     config.KafkaBroker,
		Topic:       config.KafkaTopic,
		StartOffset: kafka.LastOffset,
		GroupID:     config.KafkaGroupId,
	})
	defer func(kafkaReader *kafka.Reader) {
		err := kafkaReader.Close()
		if err != nil {
			log.Println("error in closing the kafka connection:", err)
		}
	}(kafkaReader)

	var wg sync.WaitGroup
	batch := make([][]byte, 0, config.BatchSize)
	for {
		m, err := kafkaReader.ReadMessage(context.TODO())
		if err != nil {
			break
		}
		if len(batch) == config.BatchSize {
			wg.Add(1)
			go parseRsvpData(batch, &wg)
			batch = make([][]byte, 0)
		} else {
			batch = append(batch, m.Value)
		}
	}
	wg.Wait()
	return nil
}

// NewKafkaClient function returns a new instance of the Kafka struct with the specified configuration.
func NewKafkaClient() Kafka {
	return Kafka{Brokers: config.KafkaBroker,
		Topic:       config.KafkaTopic,
		GroupID:     config.KafkaGroupId,
		StartOffset: kafka.LastOffset}
}
