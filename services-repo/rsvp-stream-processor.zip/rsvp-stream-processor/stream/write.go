package stream

import (
	"context"
	"github.com/sudhakarlarus/rsvp-stream-processor/model"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo/options"
	"log"
)

// processed function stores the processed RSVP data in the "processed-batchId" collection of the "rsvp" database.
// It takes the batchId and processedRsvp map as input, where the processedRsvp map contains the event data
// with response count, guests, last modified time, and last RSVP id.
// For each item in the processedRsvp map, the function creates a findFilter based on the event data,
// and an updateFilter to increment the response count, guests and update the last modified time and last RSVP id.
// The function uses the upsert option to insert the data if it doesn't exist, or update it if it does.
// If there is an error during the update process, it logs the error message.
// Finally, it calls the deleteFlattenData function, passing the batchId as input.
func processed(batchId int, processedRsvp map[string]model.ProcessedRsvpData) {
	d := D.GetClient()
	collection := d.Database("rsvp").Collection("processed-batch")
	for _, v := range processedRsvp {
		findFilter := bson.D{{"event_id", v.EventID},
			{"event_name", v.EventName},
			{"venue_name", v.VenueName},
			{"lon", v.Lon},
			{"lat", v.Lat}, {"group_country", v.GroupCountry}, {"group_city", v.GroupCity}}
		updateFilter := bson.M{"$inc": bson.M{"response_count": v.ResponseCount, "guests": v.Guests}, "$set": bson.M{"last_mtime": v.LastMtime, "last_rsvp_id": v.LastRSVPID}}
		updateOption := options.Update().SetUpsert(true)
		_, err := collection.UpdateOne(context.TODO(), findFilter, updateFilter, updateOption)
		if err != nil {
			log.Println("error in upserting the rsvp processed data:", err)
		}
	}
	deleteFlattenData(batchId)
}

// flatten takes an array of `model.FlatRsvpdata` objects and stores them in the database.
// Call the `aggregateRsvpData` function to process the data.
func flatten(fRsvpBatch []model.FlatRsvpdata) {
	d := D.GetClient()
	collection := d.Database("rsvp").Collection("flatten-batch")
	interfaces := make([]interface{}, len(fRsvpBatch))
	for i, v := range fRsvpBatch {
		interfaces[i] = v
	}
	_, err := collection.InsertMany(context.TODO(), interfaces)
	if err != nil {
		log.Println("error in flatten data db write for the batch:", fRsvpBatch[0].BatchId, "error:", err)
	}
	aggregateRsvpData(fRsvpBatch)
}
