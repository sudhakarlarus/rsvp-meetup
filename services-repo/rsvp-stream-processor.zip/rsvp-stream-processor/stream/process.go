package stream

import (
	"context"
	"encoding/json"
	"github.com/sudhakarlarus/rsvp-stream-processor/db"
	"github.com/sudhakarlarus/rsvp-stream-processor/model"
	"go.mongodb.org/mongo-driver/bson"
	"log"
	"sync"
)

var batchCount = 0
var D db.Db

// parseRsvpData processes a batch of RSVP data in [][]byte format.
// The input data is parsed into a slice of RSVPData structs.
// The function increases the batch count and flattens the RSVP data.
// The input waitGroup is used to wait for all goroutines to finish.
// parsedBatch will hold the parsed data in RSVPData struct format.
func parseRsvpData(value [][]byte, waitGroup *sync.WaitGroup) {
	var parsedBatch []model.RSVPData
	for _, v := range value {
		md := model.RSVPData{}
		err := json.Unmarshal(v, &md)
		if err != nil {
			log.Println("error while parsing rsvp feed:", err)
		}
		md.BatchId = batchCount
		parsedBatch = append(parsedBatch, md)
	}
	batchCount++
	flattenRsvpData(parsedBatch)
	waitGroup.Done()
}

// flattenRsvpData takes a slice of model.RSVPData as input and converts it into a slice of model.FlatRsvpdata.
func flattenRsvpData(batch []model.RSVPData) {
	var flatBatch []model.FlatRsvpdata
	for _, v := range batch {
		md := model.FlatRsvpdata{}
		md.BatchId = v.BatchId
		md.Mtime = v.Mtime
		md.VenueName = v.Venue.VenueName
		md.Lon = v.Venue.Lon
		md.Lat = v.Venue.Lat
		md.VenueID = v.Venue.VenueID
		md.Visibility = v.Visibility
		md.Response = v.Response
		md.Guests = v.Guests
		md.MemberID = v.Member.MemberID
		md.MemberName = v.Member.MemberName
		md.RSVPID = v.RSVPID
		md.EventName = v.Event.EventName
		md.EventID = v.Event.EventID
		md.Time = v.Event.Time
		md.EventURL = v.Event.EventURL
		md.GroupTopics = v.Group.GroupTopics
		md.GroupCity = v.Group.GroupCity
		md.GroupCountry = v.Group.GroupCountry
		md.GroupID = v.Group.GroupID
		md.GroupName = v.Group.GroupName
		md.GroupLon = v.Group.GroupLon
		md.GroupURLName = v.Group.GroupURLName
		md.GroupLat = v.Group.GroupLat
		flatBatch = append(flatBatch, md)
	}
	flatten(flatBatch)

}

// deleteFlattenData deletes the flattened RSVP data for a given batch from the "flatten-batch" collection in the "rsvp" database.
// It takes an integer batchId as the input, which represents the batch to be deleted.
// It uses the D.GetClient() function to get a client for the database.
// It creates a filter using the bson package to specify the batch_id to be deleted.
// It then uses the DeleteMany method on the collection to delete the matching documents.
// If there is an error, it logs.
func deleteFlattenData(batchId int) {
	log.Println("perform delete for batch:", batchId)
	d := D.GetClient()
	collection := d.Database("rsvp").Collection("flatten-batch")
	filter := bson.D{{"batch_id", batchId}}
	_, err := collection.DeleteMany(context.TODO(), filter)
	if err != nil {
		log.Println("error in deleting the flatten batch data:", err)
	}
}

// aggregateRsvpData takes a slice of FlatRsvpdata and aggregates the data into a map of ProcessedRsvpData.
// The aggregated data is then passed to the processed method for further processing.
// flatBatch: a slice of FlatRsvpdata objects
func aggregateRsvpData(flatBatch []model.FlatRsvpdata) {
	log.Println("perform aggregate for a batch:", flatBatch[len(flatBatch)-1].BatchId)
	processedRsvp := make(map[string]model.ProcessedRsvpData)

	for _, v := range flatBatch {

		if processedRsvp[v.EventID].EventID == "" {
			var rsvpdata model.ProcessedRsvpData
			rsvpdata.EventID = v.EventID
			rsvpdata.VenueName = v.VenueName
			rsvpdata.Lon = v.Lon
			rsvpdata.Lat = v.Lat
			rsvpdata.VenueID = v.VenueID
			rsvpdata.Visibility = v.Visibility
			rsvpdata.EventName = v.EventName
			rsvpdata.Time = v.Time
			rsvpdata.EventURL = v.EventURL
			rsvpdata.GroupTopics = v.GroupTopics
			rsvpdata.GroupCity = v.GroupCity
			rsvpdata.GroupCountry = v.GroupCountry
			rsvpdata.GroupID = v.GroupID
			rsvpdata.GroupName = v.GroupName
			rsvpdata.GroupLon = v.GroupLon
			rsvpdata.GroupLat = v.GroupLat
			processedRsvp[v.EventID] = rsvpdata
		}
		rsvpData := processedRsvp[v.EventID]
		rsvpData.ResponseCount += 1
		rsvpData.Guests += v.Guests
		rsvpData.LastRSVPID = v.RSVPID
		rsvpData.LastMtime = v.Mtime
		rsvpData.ProcessedBatchId = v.BatchId
		processedRsvp[v.EventID] = rsvpData
	}
	processed(flatBatch[0].BatchId, processedRsvp)
}
