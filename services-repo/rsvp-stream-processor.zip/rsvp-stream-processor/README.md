# rsvp-stream-processor

## Description
Processes real-time feeds from rsvp generator, and stores flatten and processed result in db
## High level design

![](doc/high-level.png)

## Installation
### Prerequisite
* Golang 1.19 and above
* Docker v20.10.14 and above.
* MongoDB latest
* Kafka latest version
* Zookeeper latest version

## Contact
For any discussion or feedback, please free to reach me over
[LinkedIn](https://www.linkedin.com/in/sudhakar-padmanaban-b2047588/) , [Mail](sudhakarpadmanaban14@gmail.com).
