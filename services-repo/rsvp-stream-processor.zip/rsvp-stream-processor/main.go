package main

import (
	"github.com/sudhakarlarus/rsvp-stream-processor/stream"
	"log"
)

func main() {
	log.Println("starting the rsvp-stream-processor")
	kafka := stream.NewKafkaClient()
	err := kafka.Consumer()
	if err != nil {
		log.Println("error in processing the rsvp stream:", err)
	}
	log.Println("stopping the rsvp-stream-processor")
}
