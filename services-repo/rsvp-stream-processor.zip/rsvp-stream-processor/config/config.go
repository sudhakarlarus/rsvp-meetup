package config

// DbUri MongoDB connection string that specifies the host and
// port to connect to a MongoDB database running locally or remote
var DbUri = "mongodb://db:27017"

// KafkaTopic is the name of the Kafka topic to be read.
const KafkaTopic = "myTopic"

// KafkaGroupId is the identifier of the Kafka consumer group.
const KafkaGroupId = "rsvp-reader"

// KafkaBroker is a slice of strings containing the addresses of the Kafka brokers.
var KafkaBroker = []string{"kafka:9092"}

// BatchSize is the number of messages to be processed in each batch.
const BatchSize = 100
